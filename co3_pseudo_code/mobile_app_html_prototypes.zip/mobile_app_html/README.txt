FOUR MOBILE APP WEBSITE PROTOTYPES

1. 01_mindwell_self_care.html — Mental wellbeing and self-care
2. 02_job_assistant.html — Intelligent job assistant
3. 03_parkwise_smart_parking.html — Smart parking and slot booking
4. 04_fitflow_fitness_app.html — Fitness tips, videos, diet planner and subscriptions

HOW TO USE
1. Download the HTML files or the ZIP archive.
2. Double-click any .html file to open it in Chrome, Edge, Firefox or another browser.
3. On the login screen, use the Register option or click the demo button to explore the app.

IMPORTANT
These are front-end student project prototypes made with HTML, CSS and JavaScript in a single file each. Login, registration, saved data, job choices, parking reservations and checkout are simulated in the browser. They do not use a backend, real authentication, live parking sensors, real video streaming, file uploads to a server, or a real payment gateway. A production app would need secure backend services and databases.
